from django.contrib import admin
from .models import Person, Pet

admin.site.register(Person)
admin.site.register(Pet)
